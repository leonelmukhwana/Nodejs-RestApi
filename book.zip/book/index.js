import express from 'express';
const app = express()
import mongoose from 'mongoose'
import dotenv from 'dotenv'
import authRoute from "./routes/auth.js"
import bookRoute from "./routes/Book.js";
dotenv.config();

//middlewares
app.use(express.json());
app.use("/api/", authRoute);
app.use("/api/books", bookRoute);

mongoose.connect(process.env.MONGO_URI, { useUnifiedTopology: true })
    .then(() => console.log("Databse Connected Successfuly!"))
    .catch((err) => {
        console.log(err);
    });



app.listen(3001, () => {
    console.log('Server started om this port')
})